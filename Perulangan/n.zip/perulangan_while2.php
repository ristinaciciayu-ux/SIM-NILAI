<?php
$i=1;
while($i<=10) {
    echo "5 * $i = $i <br>";
    $i++;
}
?>