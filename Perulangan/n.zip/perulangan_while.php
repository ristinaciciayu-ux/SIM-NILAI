<?php
$i=1;
while($i<=10) {
    echo "Perulangan ke- $i <br>";
    $i++;
}
?>